"""
FitBuddy Application Package
"""
