import os
from fastapi import FastAPI, Request, Query
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

# Import module functions as specified in project documentation
from qna import answer_question_with_gemini
from explanation_module import explain_topic
from summary_module import summarize_text
from quiz_module import generate_quiz
from learning_path import get_learning_recommendations

load_dotenv()

app = FastAPI(
    title="EduGenie: Google Gemini Powered Learning Assistant",
    description="A lightweight AI-powered educational assistant that simplifies learning through generative AI.",
    version="1.0.0"
)

# Ensure static and templates folders exist
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
static_dir = os.path.join(BASE_DIR, "static")
templates_dir = os.path.join(BASE_DIR, "templates")
os.makedirs(static_dir, exist_ok=True)
os.makedirs(templates_dir, exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# Initialize Jinja2 templates
templates = Jinja2Templates(directory=templates_dir)


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    """
    Renders the EduGenie frontend user interface.
    """
    return templates.TemplateResponse(request=request, name="index.html")


@app.get("/health")
async def health_check():
    """
    Health check endpoint to verify backend service status.
    """
    api_key_set = bool(os.getenv("GEMINI_API_KEY") and os.getenv("GEMINI_API_KEY") != "YOUR_GEMINI_API_KEY_HERE")
    return {
        "status": "healthy",
        "app": "EduGenie",
        "gemini_api_configured": api_key_set
    }


# ==========================================
# 1. Q&A Module API (/qa)
# ==========================================
@app.get("/qa")
async def answer_question(question: str = Query(...)):
    """
    Answers user questions using Google Gemini.
    """
    if not question or not question.strip():
        return JSONResponse(content={"error": "Please provide a question."}, status_code=400)
    answer = answer_question_with_gemini(question.strip())
    return {"answer": answer}


@app.post("/qa")
async def answer_question_post(request: Request):
    """
    POST variant for answering questions sent as JSON payload.
    """
    data = await request.json()
    question = data.get("question")
    if not question or not question.strip():
        return JSONResponse(content={"error": "Please provide a question."}, status_code=400)
    answer = answer_question_with_gemini(question.strip())
    return {"answer": answer}


# ==========================================
# 2. Explanation Module API (/explain)
# ==========================================
@app.post("/explain")
async def explain_api(request: Request):
    """
    Explains concepts simply using local LaMini model or Gemini cloud fallback.
    """
    data = await request.json()
    topic = data.get("topic")
    if not topic or not topic.strip():
        return JSONResponse(content={"error": "Please provide a topic."}, status_code=400)
    explanation = explain_topic(topic.strip())
    return {"topic": topic, "explanation": explanation}


@app.get("/explain")
async def explain_get_api(topic: str = Query(...)):
    """
    GET variant for concept explanations.
    """
    if not topic or not topic.strip():
        return JSONResponse(content={"error": "Please provide a topic."}, status_code=400)
    explanation = explain_topic(topic.strip())
    return {"topic": topic, "explanation": explanation}


# ==========================================
# 3. Summarization Module API (/summarize)
# ==========================================
@app.post("/summarize")
async def summarize_api(request: Request):
    """
    Summarizes long educational text into concise key points.
    """
    data = await request.json()
    text = data.get("text")
    if not text or not text.strip():
        return JSONResponse(content={"error": "Please provide text to summarize."}, status_code=400)
    summary = summarize_text(text.strip())
    return {"summary": summary}


# ==========================================
# 4. Quiz Generation Module API (/quiz)
# ==========================================
@app.post("/quiz")
async def quiz_api(request: Request):
    """
    Generates 3 multiple choice questions from topic or passage.
    """
    data = await request.json()
    text = data.get("text")
    if not text or not text.strip():
        return JSONResponse(content={"error": "Please provide text for quiz."}, status_code=400)
    quiz = generate_quiz(text.strip())
    print("Generated quiz:", quiz)  # 🧩 DEBUG
    return JSONResponse(content={"quiz": quiz})


# ==========================================
# 5. Learning Recommendations API (/learn/recommendations)
# ==========================================
@app.get("/learn/recommendations")
async def learning_recommendation_api(topic: str = Query(...)):
    """
    Generates structured learning paths and curated study recommendations.
    """
    if not topic or not topic.strip():
        return JSONResponse(content={"error": "Please provide a topic."}, status_code=400)
    recommendation = get_learning_recommendations(topic.strip())
    return {"topic": topic, "recommendation": recommendation}


@app.post("/learn/recommendations")
async def learning_recommendation_post_api(request: Request):
    """
    POST variant for learning recommendations.
    """
    data = await request.json()
    topic = data.get("topic")
    if not topic or not topic.strip():
        return JSONResponse(content={"error": "Please provide a topic."}, status_code=400)
    recommendation = get_learning_recommendations(topic.strip())
    return {"topic": topic, "recommendation": recommendation}


if __name__ == "__main__":
    import uvicorn
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", 8000))
    print(f"[INFO] Starting EduGenie server at http://{host}:{port}")
    uvicorn.run("main:app", host=host, port=port, reload=True)
