# EduGenie: Google Gemini Powered Learning Assistant 💡✨

EduGenie is a lightweight AI-powered educational assistant designed to simplify learning through generative AI. Built with **FastAPI** for the backend, an interactive **HTML5/CSS3/JavaScript** frontend, and powered by **Google Gemini** along with support for **LaMini-Flan-T5-783M**, EduGenie provides smart, personalized educational assistance for learners and students at all academic levels.

---

## 🌟 Key Features

1. **Ask EduGenie a Question (`/qa`)**
   - Provides smart, accurate, and concise answers to general knowledge and academic questions using Google Gemini.
2. **Concept Explanation (`/explain`)**
   - Breaks down complex concepts (e.g. *Photosynthesis*, *Quantum Computing*) into simplified, school-level explanations.
   - Built to support local instruction-tuned `MBZUAI/LaMini-Flan-T5-783M` with an automatic, resilient cloud fallback to Google Gemini.
3. **Paragraph Summarization (`/summarize`)**
   - Summarizes long educational texts and passages into concise, easy-to-understand summaries for quick revision.
4. **Interactive Quiz Generation (`/quiz`)**
   - Generates 3 multiple-choice questions (MCQs) with 4 plausible options from any given topic or text.
   - Features real-time interactive answer checking (`✅ Correct!` or `❌ Incorrect. Correct answer: ...`) in the web UI.
5. **Personalized Learning Recommendations (`/learn/recommendations`)**
   - Builds structured, step-by-step learning roadmaps (Beginner, Intermediate, Advanced) with timelines, core topics, and curated resources (books, videos, tutorials).

---

## 📂 Project Architecture

```
EduGenie/
├── .vscode/
│   ├── launch.json           # 1-Click VS Code Debug & Run configuration
│   └── settings.json         # VS Code workspace settings
├── static/
│   └── style.css             # Responsive styling, modern card layout, interactive quiz styles
├── templates/
│   └── index.html            # Frontend HTML interface with real-time fetch integration
├── .env                      # Environment variables (Gemini API key & server port)
├── .env.example              # Template environment configuration
├── explanation_module.py     # Concept explanation logic (LaMini local / Gemini fallback)
├── learning_path.py          # Structured learning recommendations module
├── main.py                   # FastAPI application, static/template mounting, REST API endpoints
├── qna.py                    # Question answering module powered by Google Gemini
├── quiz_module.py            # Quiz generation module with JSON code fence sanitization
├── requirements.txt          # Python project dependencies
├── summary_module.py         # Passage summarization module powered by Google Gemini
├── test_app.py               # Automated pytest suite testing all endpoints & validations
└── README.md                 # Complete project documentation and running guide
```

---

## ⚙️ Prerequisites

- **Python 3.10+** (Python 3.11 recommended)
- A **Google Gemini API Key** (Free from [Google AI Studio](https://aistudio.google.com/))
- **VS Code** (Visual Studio Code)

---

## 🚀 Quick Setup & Installation

### Step 1: Open the Project in VS Code
Open VS Code, click **File > Open Folder...**, and select the `EduGenie` folder:
```
c:\Users\user\Pictures\EduGenie
```

### Step 2: Open a Terminal in VS Code
In VS Code, press <kbd>Ctrl</kbd> + <kbd>`</kbd> (or go to **Terminal > New Terminal**).

### Step 3: (Recommended) Create & Activate Virtual Environment
```powershell
# Create virtual environment
python -m venv .venv

# Activate virtual environment on Windows PowerShell
.\.venv\Scripts\Activate.ps1
```
*(If execution policy prevents script running, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in your terminal).*

### Step 4: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 5: Configure your Google Gemini API Key
1. Get an API key for free at [Google AI Studio](https://aistudio.google.com/).
2. Open the `.env` file in the root directory:
   ```env
   GEMINI_API_KEY=your_actual_gemini_api_key_here
   GEMINI_MODEL=models/gemini-1.5-pro
   HOST=127.0.0.1
   PORT=8000
   ```
3. Replace `YOUR_GEMINI_API_KEY_HERE` with your actual key and save the file.

---

## ▶️ Running the Application

### Option A: 1-Click Run in VS Code (F5)
1. Open the project in VS Code.
2. Press <kbd>F5</kbd> (or go to **Run and Debug** in the left sidebar and click **Run "Python: EduGenie (FastAPI)"**).
3. The server starts with hot reload enabled.

### Option B: From the Terminal
Run the ASGI server via Uvicorn:
```bash
uvicorn main:app --reload
```
or run with Python directly:
```bash
python main.py
```

### Accessing the Web Application
Open your web browser and navigate to:
```
http://127.0.0.1:8000
```
Interactive Swagger API documentation is available at:
```
http://127.0.0.1:8000/docs
```

---

## 🧪 Testing the Application

A complete automated test suite is included in `test_app.py` covering:
- Template rendering and HTML delivery (`GET /`)
- Static CSS file loading (`GET /static/style.css`)
- Health check endpoint (`GET /health`)
- Input validation and 400/422 status codes for all endpoints
- AI response mocking and payload formatting for Q&A, Explain, Summary, Quiz, and Learning Recommendations
- Markdown code block stripper and JSON parsing robustness

Run all tests with:
```bash
pytest test_app.py -v
```

---

## 🔌 API Endpoints Reference

| Endpoint | Method | Input Parameters / Payload | Description |
| :--- | :---: | :--- | :--- |
| `/` | `GET` | None | Renders the web interface (`index.html`) |
| `/health` | `GET` | None | Returns application health status and API key setup check |
| `/qa` | `GET` / `POST` | `question` (Query param or JSON `{"question": "..."}`) | Answers educational questions |
| `/explain` | `POST` / `GET` | JSON `{"topic": "..."}` or `topic` query param | Generates simplified concept explanations |
| `/summarize` | `POST` | JSON `{"text": "..."}` | Summarizes long paragraphs into key points |
| `/quiz` | `POST` | JSON `{"text": "..."}` | Generates 3 MCQs with 4 options and answers |
| `/learn/recommendations` | `GET` / `POST` | `topic` (Query param or JSON `{"topic": "..."}`) | Returns structured learning roadmaps |

---

## 💡 Local Model Note (`LaMini-Flan-T5-783M`)

The concept explanation module (`explanation_module.py`) is designed as specified in the project architecture to use `MBZUAI/LaMini-Flan-T5-783M`.
- If `torch` and `transformers` are installed in your environment, the local model will be lazy-loaded on the first explanation request.
- If PyTorch is not installed or network constraints prevent downloading the model weights, EduGenie will **automatically and seamlessly fall back to Google Gemini** using the exact same prompt, guaranteeing 100% uptime with zero crashes.
