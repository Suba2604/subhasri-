import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

# Configure API Key
api_key = os.getenv("GEMINI_API_KEY")
if api_key:
    genai.configure(api_key=api_key)


def summarize_text(text: str) -> str:
    try:
        model_name = os.getenv("GEMINI_MODEL", "models/gemini-1.5-pro")
        model = genai.GenerativeModel(model_name=model_name)
        prompt = f"Summarize the following text in simple language:\n\n{text}"
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Error in Summary: {e}"
