import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

# Configure API Key
api_key = os.getenv("GEMINI_API_KEY")
if api_key:
    genai.configure(api_key=api_key)


def answer_question_with_gemini(question: str) -> str:
    try:
        model_name = os.getenv("GEMINI_MODEL", "models/gemini-1.5-pro")
        model = genai.GenerativeModel(model_name=model_name)
        response = model.generate_content(question)
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Error in QnA: {e}"
