import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock

from main import app
from quiz_module import clean_json_block

client = TestClient(app)


def test_root_endpoint():
    """Verify that root endpoint serves the HTML page correctly."""
    response = client.get("/")
    assert response.status_code == 200
    assert "EduGenie" in response.text
    assert "Ask EduGenie a Question" in response.text
    assert "Need an Explanation" in response.text
    assert "Generate a Quiz" in response.text


def test_static_css_endpoint():
    """Verify static CSS stylesheet is accessible."""
    response = client.get("/static/style.css")
    assert response.status_code == 200
    assert "EduGenie" in response.text or "card" in response.text


def test_health_check_endpoint():
    """Verify health check endpoint returns 200 OK."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["app"] == "EduGenie"


# ==========================================
# Validation & Error Handling Tests
# ==========================================

def test_qa_validation_missing_param():
    """GET /qa requires 'question' query parameter."""
    response = client.get("/qa")
    assert response.status_code == 422


def test_explain_validation_missing_topic():
    """POST /explain requires non-empty 'topic'."""
    response = client.post("/explain", json={})
    assert response.status_code == 400
    assert "error" in response.json()


def test_summarize_validation_missing_text():
    """POST /summarize requires non-empty 'text'."""
    response = client.post("/summarize", json={})
    assert response.status_code == 400
    assert "error" in response.json()


def test_quiz_validation_missing_text():
    """POST /quiz requires non-empty 'text'."""
    response = client.post("/quiz", json={})
    assert response.status_code == 400
    assert "error" in response.json()


def test_learning_recommendation_validation_missing_topic():
    """GET /learn/recommendations requires 'topic' query parameter."""
    response = client.get("/learn/recommendations")
    assert response.status_code == 422


# ==========================================
# Functional Tests with Mocked AI Responses
# ==========================================

@patch("main.answer_question_with_gemini")
def test_qa_endpoint_success(mock_answer):
    mock_answer.return_value = "The Pacific Ocean is the largest ocean on Earth."
    response = client.get("/qa?question=Which is the largest ocean?")
    assert response.status_code == 200
    data = response.json()
    assert "answer" in data
    assert "Pacific Ocean" in data["answer"]


@patch("main.explain_topic")
def test_explain_endpoint_success(mock_explain):
    mock_explain.return_value = "Photosynthesis is the process by which green plants make food using sunlight."
    response = client.post("/explain", json={"topic": "Photosynthesis"})
    assert response.status_code == 200
    data = response.json()
    assert data["topic"] == "Photosynthesis"
    assert "sunlight" in data["explanation"]


@patch("main.summarize_text")
def test_summarize_endpoint_success(mock_summarize):
    mock_summarize.return_value = "The Industrial Revolution transformed manufacturing with steam power."
    response = client.post("/summarize", json={"text": "Long paragraph about industrial revolution..."})
    assert response.status_code == 200
    data = response.json()
    assert "summary" in data
    assert "Industrial Revolution" in data["summary"]


@patch("main.generate_quiz")
def test_quiz_endpoint_success(mock_quiz):
    mock_quiz.return_value = [
        {
            "question": "What does the Pythagorean theorem describe?",
            "options": [
                "The relationship between the angles of a triangle.",
                "The relationship between the sides of a right-angled triangle.",
                "The relationship between the area and perimeter of a triangle.",
                "The relationship between the sides of any triangle."
            ],
            "answer": "The relationship between the sides of a right-angled triangle."
        }
    ]
    response = client.post("/quiz", json={"text": "Pythagoras theorem"})
    assert response.status_code == 200
    data = response.json()
    assert "quiz" in data
    assert len(data["quiz"]) == 1
    assert data["quiz"][0]["answer"] == "The relationship between the sides of a right-angled triangle."


@patch("main.get_learning_recommendations")
def test_learning_recommendation_endpoint_success(mock_recs):
    mock_recs.return_value = "## SQL Learning Path: From Zero to Hero\n**I. Beginner Level: Building a Foundation**"
    response = client.get("/learn/recommendations?topic=SQL")
    assert response.status_code == 200
    data = response.json()
    assert data["topic"] == "SQL"
    assert "SQL Learning Path" in data["recommendation"]


# ==========================================
# JSON Parser Helper Tests
# ==========================================

def test_clean_json_block():
    markdown_fenced = "```json\n[{\"question\": \"Test?\", \"options\": [\"A\", \"B\"], \"answer\": \"A\"}]\n```"
    cleaned = clean_json_block(markdown_fenced)
    assert cleaned.startswith("[")
    assert cleaned.endswith("]")

    plain_fenced = "```\n[{\"question\": \"Test?\"}]\n```"
    cleaned_plain = clean_json_block(plain_fenced)
    assert cleaned_plain.startswith("[")
