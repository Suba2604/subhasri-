"""LegalEase FastAPI Backend Application Module"""
