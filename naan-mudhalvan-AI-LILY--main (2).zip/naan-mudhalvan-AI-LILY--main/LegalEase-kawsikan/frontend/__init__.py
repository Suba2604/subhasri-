"""LegalEase Frontend Streamlit Application Module"""
